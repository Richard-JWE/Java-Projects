to run: java -cp .:algs4.jar PercolationStats 200 100

